# AHK-Object-Oriented-GUIs
A library for making working with GUIs in AHK v1.1 object oriented.

# Documentation
http://ahk-object-oriented-guis.readthedocs.io/en/latest/index.html
