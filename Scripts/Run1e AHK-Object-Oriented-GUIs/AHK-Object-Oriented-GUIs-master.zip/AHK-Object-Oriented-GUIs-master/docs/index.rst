.. AHK Object Oriented GUIs documentation master file, created by
   sphinx-quickstart on Fri Feb 16 17:48:43 2018.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

Welcome to AHK Object Oriented GUIs's documentation!
====================================================

AHK-OOG is a library makes it easy to work with GUIs in AutoHotkey in an object-oriented fashion.

.. toctree::
   :maxdepth: 2
   :caption: Table of Contents
   
   getting-started
   additional
   documentation
   examples
   about


Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`
