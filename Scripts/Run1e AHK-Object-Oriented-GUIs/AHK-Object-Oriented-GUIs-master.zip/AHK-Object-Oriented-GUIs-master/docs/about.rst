########
About
########

AHK Object Oriented GUIs is an attempt at making working with GUIs in AHK v1.1 more intuitive and clean.
It aims at providing an object oriented way of working with GUIs.

Need help?
~~~~~~~~~~

Talk to me on the official AutoHotkey Discord server!

Invite: https://discord.gg/g5MagEr