###############
Examples
###############

Class example
============

In this example we extend the ``GuiBase`` class and build upon it to make our own GUI.

.. code-block: ahk

